SourceVMT - Color Tool
--------------------------------------------------------------

Usage: You can use this tool to basically generate source vectors for VMTs

Examples of use:

"$envmaptint"
"$phongtint"
"$phongalbedotint"
"$detailtint"
"$selfillumtint"
"$FleshSubsurfacetint"
